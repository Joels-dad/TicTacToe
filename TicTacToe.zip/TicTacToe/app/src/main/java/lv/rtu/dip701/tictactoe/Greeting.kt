package lv.rtu.dip701.tictactoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import lv.rtu.dip701.tictactoe.databinding.ActivityGreetingBinding


class Greeting : AppCompatActivity() {

    private lateinit var binding: ActivityGreetingBinding
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGreetingBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_greeting)
        binding.buttonTwo.setOnClickListener{}

        nextButton = findViewById(R.id.buttonTwo)


        nextButton.setOnClickListener {
            val intent = Intent(this, StartScreen::class.java)

            startActivity(intent)
        }
    }







}