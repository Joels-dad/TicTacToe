package lv.rtu.dip701.tictactoe

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class StartScreen : AppCompatActivity() {

    private lateinit var playerOne: EditText
    private lateinit var playerTwo: EditText
    private lateinit var playerNameButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_screen)
        playerOne = findViewById(R.id.playerOneName)
        playerTwo = findViewById(R.id.playerTwoName)
        playerNameButton = findViewById(R.id.buttonOne)


        playerNameButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            val getPlayerOne = playerOne.text.toString()
            val getPlayerTwo = playerTwo.text.toString()

            intent.putExtra("Name1", getPlayerOne)
            intent.putExtra("Name2", getPlayerTwo)
            startActivity(intent)
        }



    }
}